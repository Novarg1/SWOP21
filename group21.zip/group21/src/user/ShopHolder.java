package user;

public class ShopHolder extends User
{

	public ShopHolder(String username) {
		super(username);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getRole() {
		// TODO Auto-generated method stub
		return "ShopHolder";
	}

}
