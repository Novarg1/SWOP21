package user;

public class Mechanic extends User
{

	public Mechanic(String username) {
		super(username);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getRole() {
		// TODO Auto-generated method stub
		return "Mechanic";
	}

}
