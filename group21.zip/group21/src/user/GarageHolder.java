package user;

public class GarageHolder extends User
{

	public GarageHolder(String username) {
		super(username);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getRole() {
		// TODO Auto-generated method stub
		return "GarageHolder";
	}

}
