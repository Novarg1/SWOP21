package company.workstations;

public class AccessoriesPost extends Workstation {

}