package company.workstations;

public class BodyPost extends Workstation {

}
