package company.workstations;

public class CargoPost extends Workstation {

}
