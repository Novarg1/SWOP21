package company.workstations;

public class CertificationPost extends Workstation {

}
