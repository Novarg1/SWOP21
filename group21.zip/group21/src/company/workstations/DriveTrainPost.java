package company.workstations;

public class DriveTrainPost extends Workstation {

}
