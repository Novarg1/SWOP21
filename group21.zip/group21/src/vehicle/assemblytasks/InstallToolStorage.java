package vehicle.assemblytasks;

public class InstallToolStorage extends CargoTask {

	@Override
	public String toString() {
		return "Install tool storage";
	}
}
