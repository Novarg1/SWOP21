package vehicle.assemblytasks;

public class AddCargoProtection extends CargoTask {

	@Override
	public String toString() {
		return "Add cargo protection";
	}
}
